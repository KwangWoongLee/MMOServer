#pragma once
#include "stdafx.h"

extern class ThreadManager*	gThreadManager;
extern class GlobalQueue* gGlobalQueue;
extern class JobTimer* gJobTimer;
